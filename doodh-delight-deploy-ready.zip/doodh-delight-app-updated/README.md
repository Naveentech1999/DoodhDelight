# Doodh Delight — Milk Delivery Manager

A redesigned Android-first React Native / Expo app following the supplied orange-and-white milk delivery app references.

## UI included
- Orange branded header with scooter delivery identity
- Date selector and Today shortcut
- Home dashboard with milk brand cards, payment summary and quick glance
- Deliveries tab with present/absent controls and packet counters
- Bills tab with monthly summary and customer breakdown
- Customers tab with search, add and edit
- Admin tab with milk catalogue, prices, commission and Firebase setup status
- Bottom navigation with Home, Deliveries, Bills, Customers and Admin

## Run in VS Code
Use Node.js 22.13+ and Expo Go compatible with the Expo SDK in this package.

```bash
npm install
npx expo install --fix
npx expo-doctor
npx expo start --go --lan --clear
```

Scan the QR code with Expo Go while the phone and PC are on the same Wi-Fi. For mobile data, sign into Expo and use `npx expo start --go --tunnel --clear`.

Web preview:
```bash
npx expo install react-dom react-native-web @expo/metro-runtime
npx expo start --web
```

## Firebase
1. Create a Firebase project and a Web App.
2. Enable Email/Password in Firebase Authentication and create your admin user.
3. Create Firestore.
4. Copy Firebase config into `src/firebase.ts`.
5. Publish `firestore.rules`.
6. The Firebase authentication screen appears when Firebase config is filled in. Sign in with your admin account.
7. In Admin, use **Import sample data** once to add 83 sample customers and sample milk products if the collections are empty.

Until Firebase is configured, the app uses local sample data. Local demo changes are held in memory and reset on app restart.

## Important
- Customer/product names, quantities, rates and bill amounts are illustrative sample data only.
- Each saved delivery line stores its unit price at the time of delivery, preserving historical bills.
- This is a prototype. Restrict Firestore access to your admin UID before storing real customer information.
- Payment collection/settlement ledger and production-grade export/backup are not implemented yet.


## Your Firebase project and actual customer import

This version is configured for Firebase project `doodhdelight` and uses Firebase Authentication + Cloud Firestore on both web and Android. Firebase Analytics is intentionally not initialised in the shared React Native module.

### Import your uploaded customer schedule
1. In Firebase Authentication, enable Email/Password and create your admin user.
2. In `firestore.rules`, replace `REPLACE_WITH_YOUR_ADMIN_EMAIL` with the exact admin email, then publish the rules in Firebase Console > Firestore > Rules.
3. Run the app, sign in, open Admin > Firebase Database.
4. Tap **Import actual customer list (63)**.
5. Verify `customers`, `milkProducts`, and `appSettings/customerImport` in Firestore.

Each customer Firestore document includes the source customer name, assigned milkItems, daily litres, pricing unit and rates. Starred ₹10 products are represented as ₹10 per 200 ml packet. The importer uses merge writes and does not delete unrelated documents.

### Important limitations / next implementation
- The import button writes actual customer master data and milk catalogue to Firestore. It does not invent attendance or historical delivery records.
- The current attendance screen still needs a follow-up UI/data-model change to render each customer's `milkItems` as their own assigned product rows and to save extra/return packet counts against daily records. The customer assignment data is already stored in each Firestore customer document.
- The Firebase web API key is included as a client identifier. It is not a server secret. Never put service-account private keys in the app.


## Customer list added to the app

The app now bundles the latest customer list you supplied (`src/customer-import-v4.json`).
It preserves 100 source rows as individual milk assignments, grouped under 82 exact customer/location labels.
Multiple milk types for one exact location stay together as separate assignments. No flat numbers are invented.
Starred ₹10 rates are stored as per-200 ml packet rates; all other prices are per litre.

- In demo mode, the Customers screen loads this list locally.
- With Firebase configured and an admin signed in, open **Admin → Firebase Database → Add my customer list (100 rows)** to write the customer profiles and milk catalogue to Firestore.
- The import uses merge writes, so it updates matching document IDs without deleting unrelated documents.


## Customer list startup behavior (updated)
After the admin signs in, the app checks the `customers` collection. If it is empty, it automatically imports the confirmed customer schedule and milk catalogue into Firestore. This creates 82 customer/location profiles from 100 original assignment rows, preserving all 100 assignments as separate milk lines. If Firestore already contains customer documents, it does not overwrite them; use Admin > Firebase Database > Add my customer list (100 rows) if you intentionally want to add the supplied schedule.
