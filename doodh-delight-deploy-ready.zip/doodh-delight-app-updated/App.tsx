import React, { useEffect, useMemo, useState } from "react";
import {
  Alert, KeyboardAvoidingView, Modal, Platform, SafeAreaView, ScrollView,
  StatusBar, StyleSheet, Text, TextInput, TouchableOpacity, View
} from "react-native";
import { StatusBar as ExpoStatusBar } from "expo-status-bar";
import AsyncStorage from "@react-native-async-storage/async-storage";
import {
  collection, doc, getDocs, onSnapshot, setDoc, writeBatch
} from "firebase/firestore";
import {
  onAuthStateChanged, signInWithEmailAndPassword, signOut, User
} from "firebase/auth";
import { auth, db, firebaseConfigured } from "./src/firebase";
import customerImport from "./src/customer-import-v4.json";

type Tab = "Home" | "Deliveries" | "Bills" | "Customers" | "Admin";
type Product = { id:string; brand:string; type:string; sizeMl:number; price:number; active:boolean };
type Customer = { id:string; name:string; phone?:string; address?:string; active:boolean; prices?:Record<string,number>; milkItems?:Array<{brandType:string; dailyLitres:number; priceUnit:"perLitre"|"perPacket"; pricePerLitre?:number; pricePerPacket?:number; packetSizeMl?:number; regularPackets?:number; dailyAmount?:number}>; dailyTotalLitres?:number; estimatedDailyAmount?:number };
type Line = { productId:string; packets:number; unitPrice:number };
type RecordDay = { customerId:string; date:string; present:boolean; absent:boolean; lines:Line[] };
type AppData = { customers:Customer[]; products:Product[]; records:RecordDay[] };

const ORANGE = "#FF8619";
const ORANGE_DARK = "#F47708";
const BLUE = "#2867DF";
const NAVY = "#1B2A43";
const GREEN = "#19875B";
const MUTED = "#87909C";
const BG = "#F1F3F7";
const todayKey = (d=new Date()) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
const money = (n:number) => `₹${n.toLocaleString("en-IN",{minimumFractionDigits:2,maximumFractionDigits:2})}`;
const fmtDate = (key:string) => { const [y,m,d]=key.split("-"); return `${d}/${m}/${y}`; };
const months = ["January","February","March","April","May","June","July","August","September","October","November","December"];

const productSeed:Product[] = [
  {id:"heritage-tm",brand:"Heritage",type:"TM",sizeMl:500,price:28,active:true},
  {id:"heritage-cm",brand:"Heritage",type:"CM",sizeMl:500,price:30,active:true},
  {id:"heritage-wm",brand:"Heritage",type:"WM",sizeMl:500,price:34,active:true},
  {id:"heritage-sm",brand:"Heritage",type:"SM",sizeMl:500,price:32,active:true},
  {id:"vijaya-tm",brand:"Vijaya",type:"TM",sizeMl:500,price:27,active:true},
  {id:"vijaya-cm",brand:"Vijaya",type:"CM",sizeMl:500,price:29,active:true},
  {id:"amul-tm",brand:"Amul",type:"TM",sizeMl:500,price:29,active:true},
  {id:"amul-a2",brand:"Amul",type:"A2",sizeMl:500,price:40,active:true},
  {id:"amul-gold",brand:"Amul",type:"Gold",sizeMl:500,price:35,active:true},
  {id:"jersey-tm",brand:"Jersey",type:"TM",sizeMl:500,price:28,active:true},
  {id:"jersey-wm",brand:"Jersey",type:"WM",sizeMl:500,price:34,active:true},
  {id:"curd-small",brand:"Dairy Products",type:"Curd packet",sizeMl:200,price:15,active:true},
];
const customerNames = [
  "Beside My-Village Apt","Nath Apartment","Nath Apartment","Nath Apartment","Village One Apartments",
  "Green Park Residency","Sai Residency","Sunshine Apartments","Lake View Homes","Sri Sai Nilayam",
  "Raghavendra Colony","Krishna Residency","Venkateswara Homes","Anand Nilayam","Srinivasa Apartments",
  "Royal Enclave","Shanti Nagar Home","Sai Krupa","Golden Heights","Meenakshi Residency"
];
const customerSeed:Customer[] = Array.from({length:83},(_,i)=>({
  id:`customer-${String(i+1).padStart(3,"0")}`,
  name:customerNames[i%customerNames.length] + (i>=customerNames.length ? ` ${Math.floor(i/customerNames.length)+1}` : ""),
  phone:`90000${String(10000+i)}`,
  address:["2nd floor box","2nd floor left","2nd floor right","1st floor bucket","Ground floor"][i%5],
  active:true,
  prices:{}
}));
const makeSeed = ():AppData => ({
  customers: ((customerImport as any).customers as Customer[]),
  products: ((customerImport as any).products as Product[]),
  records: []
});

export default function App(){
  const [tab,setTab]=useState<Tab>("Home");
  const [data,setData]=useState<AppData>(makeSeed());
  const [selectedDate,setSelectedDate]=useState(todayKey());
  const [selectedMonth,setSelectedMonth]=useState(todayKey().slice(0,7));
  const [search,setSearch]=useState("");
  const [customerModal,setCustomerModal]=useState(false);
  const [editing,setEditing]=useState<Customer|null>(null);
  const [name,setName]=useState(""); const [phone,setPhone]=useState(""); const [address,setAddress]=useState("");
  const [productModal,setProductModal]=useState(false);
  const [brand,setBrand]=useState(""); const [type,setType]=useState(""); const [size,setSize]=useState("500"); const [price,setPrice]=useState("");
  const [commission,setCommission]=useState("0");
  const [authUser,setAuthUser]=useState<User|null>(null);
  const [authReady,setAuthReady]=useState(!firebaseConfigured);
  const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [authError,setAuthError]=useState("");
  const [busy,setBusy]=useState(false);

  useEffect(()=>{
    if(firebaseConfigured && auth) return onAuthStateChanged(auth,u=>{setAuthUser(u);setAuthReady(true);});
  },[]);
  useEffect(()=>{
    if(firebaseConfigured && !authUser) return;
    if(firebaseConfigured && db){
      const unsubs=[
        onSnapshot(collection(db,"customers"),s=>setData(prev=>({...prev,customers:s.docs.map(d=>d.data() as Customer)}))),
        onSnapshot(collection(db,"milkProducts"),s=>setData(prev=>({...prev,products:s.docs.map(d=>d.data() as Product)}))),
        onSnapshot(collection(db,"dailyRecords"),s=>setData(prev=>({...prev,records:s.docs.map(d=>d.data() as RecordDay)}))),
      ];
      return ()=>unsubs.forEach(u=>u());
    }
    AsyncStorage.getItem("doodh-delight-demo").then(raw=>{if(raw){try{setData(JSON.parse(raw));}catch{}}});
  },[authUser]);

  // First-run setup: after an admin signs in, automatically seed the confirmed
  // customer schedule if this Firestore project has no customer documents yet.
  useEffect(()=>{
    if(!firebaseConfigured || !db || !authUser) return;
    let cancelled = false;
    (async()=>{
      try{
        const existing = await getDocs(collection(db,"customers"));
        if(!existing.empty || cancelled) return;
        const sourceCustomers = (customerImport as any).customers as Customer[];
        const sourceProducts = (customerImport as any).products as Product[];
        const batch = writeBatch(db);
        sourceCustomers.forEach(customer=>batch.set(doc(db!,"customers",customer.id),customer));
        sourceProducts.forEach(product=>batch.set(doc(db!,"milkProducts",product.id),product));
        batch.set(doc(db!,"appSettings","customerImport"),{
          importedAt:new Date().toISOString(),
          source:"confirmed user-provided customer list",
          customerCount:sourceCustomers.length,
          sourceRowCount:(customerImport as any).sourceRowCount,
          productCount:sourceProducts.length,
          starredPacketPrice:10,
          starredPacketSizeMl:200,
          automaticFirstRunImport:true
        });
        await batch.commit();
        if(!cancelled) Alert.alert("Your customers are ready",`${sourceCustomers.length} customer/location profiles and all ${(customerImport as any).sourceRowCount} milk assignment rows have been added to Firestore.`);
      }catch(e:any){
        if(!cancelled) Alert.alert("Customer setup failed",e.message??String(e));
      }
    })();
    return ()=>{cancelled=true;};
  },[authUser]);
  useEffect(()=>{if(!firebaseConfigured) AsyncStorage.setItem("doodh-delight-demo",JSON.stringify(data)).catch(()=>{});},[data]);

  const activeCustomers=data.customers.filter(c=>c.active);
  const dayRecords=data.records.filter(r=>r.date===selectedDate);
  const recordFor=(id:string):RecordDay=>dayRecords.find(r=>r.customerId===id)??{customerId:id,date:selectedDate,present:false,absent:false,lines:[]};
  const productById=(id:string)=>data.products.find(p=>p.id===id);
  const recordTotal=(r:RecordDay)=>r.lines.reduce((s,l)=>s+l.packets*l.unitPrice,0);
  const recordLitres=(r:RecordDay)=>r.lines.reduce((s,l)=>s+(productById(l.productId)?.sizeMl??0)*l.packets/1000,0);
  const dayTotal=dayRecords.reduce((s,r)=>s+recordTotal(r),0);
  const dayLitres=dayRecords.reduce((s,r)=>s+recordLitres(r),0);
  const dayPackets=dayRecords.reduce((s,r)=>s+r.lines.reduce((a,l)=>a+l.packets,0),0);
  const deliveredCount=dayRecords.filter(r=>r.present&&r.lines.length>0).length;
  const absentCount=dayRecords.filter(r=>r.absent).length;
  const notMarked=Math.max(0,activeCustomers.length-deliveredCount-absentCount);
  const monthRecords=data.records.filter(r=>r.date.startsWith(selectedMonth));
  const monthTotal=monthRecords.reduce((s,r)=>s+recordTotal(r),0);
  const monthLitres=monthRecords.reduce((s,r)=>s+recordLitres(r),0);
  const monthDays=monthRecords.filter(r=>r.lines.length>0).length;

  const persistCustomer=async(c:Customer)=>{
    if(firebaseConfigured&&db) await setDoc(doc(db,"customers",c.id),c);
    setData(prev=>({...prev,customers:prev.customers.some(x=>x.id===c.id)?prev.customers.map(x=>x.id===c.id?c:x):[...prev.customers,c]}));
  };
  const persistProduct=async(p:Product)=>{
    if(firebaseConfigured&&db) await setDoc(doc(db,"milkProducts",p.id),p);
    setData(prev=>({...prev,products:prev.products.some(x=>x.id===p.id)?prev.products.map(x=>x.id===p.id?p:x):[...prev.products,p]}));
  };
  const persistRecord=async(r:RecordDay)=>{
    if(firebaseConfigured&&db) await setDoc(doc(db,"dailyRecords",`${r.date}_${r.customerId}`),r);
    setData(prev=>({...prev,records:prev.records.some(x=>x.date===r.date&&x.customerId===r.customerId)?prev.records.map(x=>x.date===r.date&&x.customerId===r.customerId?r:x):[...prev.records,r]}));
  };
  const togglePresent=(c:Customer)=>{
    const r=recordFor(c.id); const next=!r.present;
    persistRecord({...r,present:next,absent:false,lines:next?r.lines:[]}).catch(e=>Alert.alert("Save error",String(e)));
  };
  const toggleAbsent=(c:Customer)=>{
    const r=recordFor(c.id); persistRecord({...r,present:false,absent:!r.absent,lines:[]}).catch(e=>Alert.alert("Save error",String(e)));
  };
  const changePacket=(c:Customer,p:Product,delta:number)=>{
    const r=recordFor(c.id); const old=r.lines.find(l=>l.productId===p.id);
    const count=Math.max(0,(old?.packets??0)+delta);
    const unitPrice=c.prices?.[p.id]??p.price;
    const lines=r.lines.filter(l=>l.productId!==p.id);
    if(count>0) lines.push({productId:p.id,packets:count,unitPrice:old?.unitPrice??unitPrice});
    persistRecord({...r,present:true,absent:false,lines}).catch(e=>Alert.alert("Save error",String(e)));
  };
  const startAddCustomer=()=>{setEditing(null);setName("");setPhone("");setAddress("");setCustomerModal(true);};
  const startEditCustomer=(c:Customer)=>{setEditing(c);setName(c.name);setPhone(c.phone);setAddress(c.address);setCustomerModal(true);};
  const saveCustomer=async()=>{
    if(!name.trim()) return Alert.alert("Name required","Enter customer name.");
    const c:Customer={id:editing?.id??`customer-${Date.now()}`,name:name.trim(),phone:phone.trim(),address:address.trim(),active:editing?.active??true,prices:editing?.prices??{},milkItems:editing?.milkItems??[],dailyTotalLitres:editing?.dailyTotalLitres,estimatedDailyAmount:editing?.estimatedDailyAmount};
    try{await persistCustomer(c);setCustomerModal(false);}catch(e:any){Alert.alert("Could not save",e.message);}
  };
  const saveProduct=async()=>{
    if(!brand.trim()||!type.trim()||!Number(size)||!price.trim()||Number(price)<0) return Alert.alert("Check product","Enter brand, type, packet size and price.");
    const p:Product={id:`product-${Date.now()}`,brand:brand.trim(),type:type.trim(),sizeMl:Number(size),price:Number(price),active:true};
    try{await persistProduct(p);setProductModal(false);setBrand("");setType("");setPrice("");}catch(e:any){Alert.alert("Could not save",e.message);}
  };
  const importActualCustomers=async()=>{
    if(!firebaseConfigured||!db){
      setData(prev=>({...prev,
        customers:(customerImport as any).customers as Customer[],
        products:(customerImport as any).products as Product[]
      }));
      Alert.alert("Customer list loaded","Your 100 source rows are now shown as 82 customer/location profiles with all milk assignments kept separately. Connect Firebase to sync them to Firestore.");
      return;
    }
    setBusy(true);
    try{
      const sourceCustomers = (customerImport as any).customers as Customer[];
      const sourceProducts = (customerImport as any).products as Product[];
      const batch = writeBatch(db);
      sourceCustomers.forEach((customer)=>{
        batch.set(doc(db!,"customers",customer.id),customer,{merge:true});
      });
      sourceProducts.forEach((product)=>{
        batch.set(doc(db!,"milkProducts",product.id),product,{merge:true});
      });
      batch.set(doc(db!,"appSettings","customerImport"),{
        importedAt:new Date().toISOString(),
        source:"confirmed user-provided customer list",
        customerCount:sourceCustomers.length,
        sourceRowCount:(customerImport as any).sourceRowCount,
        productCount:sourceProducts.length,
        starredPacketPrice:10,
        starredPacketSizeMl:200
      },{merge:true});
      await batch.commit();
      Alert.alert("Customer data added",`${sourceCustomers.length} customer/location profiles, ${sourceProducts.length} milk products and all ${(customerImport as any).sourceRowCount} original milk assignment rows were saved to Firestore.`);
    }catch(e:any){Alert.alert("Import failed",e.message??String(e));}
    finally{setBusy(false);}
  };
  const importSamples=async()=>{
    if(firebaseConfigured&&db){
      setBusy(true);
      try{
        const [cs,ps]=await Promise.all([getDocs(collection(db,"customers")),getDocs(collection(db,"milkProducts"))]);
        const batch=writeBatch(db);
        if(cs.empty) customerSeed.forEach(c=>batch.set(doc(db!,"customers",c.id),c));
        if(ps.empty) productSeed.forEach(p=>batch.set(doc(db!,"milkProducts",p.id),p));
        await batch.commit(); Alert.alert("Sample data imported","Sample customers and milk products are ready.");
      }catch(e:any){Alert.alert("Import failed",e.message);}finally{setBusy(false);}
    }else{
      setData(prev=>({...prev,customers:prev.customers.length?prev.customers:customerSeed,products:prev.products.length?prev.products:productSeed}));
      Alert.alert("Demo data ready","Customer list and milk products are loaded from your uploaded data.");
    }
  };
  const changeDate=(delta:number)=>{
    const d=new Date(`${selectedDate}T12:00:00`); d.setDate(d.getDate()+delta); setSelectedDate(todayKey(d));
  };
  const dateLabel=fmtDate(selectedDate);
  const titleMonth=(()=>{const [y,m]=selectedMonth.split("-").map(Number);return `${months[m-1]} ${y}`;})();
  const filteredCustomers=activeCustomers.filter(c=>(c.name+" "+c.address+" "+c.phone).toLowerCase().includes(search.toLowerCase()));

  if(firebaseConfigured&&!authReady) return <SafeAreaView style={styles.center}><Text style={styles.brand}>Doodh Delight</Text><Text style={styles.muted}>Checking admin session…</Text></SafeAreaView>;
  if(firebaseConfigured&&!authUser) return <SafeAreaView style={styles.safe}><ExpoStatusBar style="dark"/><View style={styles.loginBox}><Text style={styles.brand}>Doodh Delight</Text><Text style={styles.subtitle}>Admin sign in</Text><Field label="Email" value={email} onChange={setEmail} placeholder="admin@example.com"/><Field label="Password" value={password} onChange={setPassword} placeholder="Password"/>{!!authError&&<Text style={styles.error}>{authError}</Text>}<Primary label="Sign in" onPress={()=>auth&&signInWithEmailAndPassword(auth,email.trim(),password).catch(e=>setAuthError(e.message))}/></View></SafeAreaView>;

  return <SafeAreaView style={styles.safe}>
    <ExpoStatusBar style="dark" backgroundColor={ORANGE}/>
    <StatusBar backgroundColor={ORANGE} barStyle="dark-content"/>
    <Header/>
    <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
      {tab!=="Bills"&&<DatePanel date={dateLabel} onPrev={()=>changeDate(-1)} onNext={()=>changeDate(1)} onToday={()=>setSelectedDate(todayKey())}/>}
      {tab==="Home"&&<HomeScreen
        customers={activeCustomers.length} delivered={deliveredCount} absent={absentCount} notMarked={notMarked}
        dayLitres={dayLitres} dayTotal={dayTotal} dayPackets={dayPackets} products={data.products}
        monthTotal={monthTotal} selectedMonth={titleMonth} onGo={setTab} records={dayRecords} productById={productById}
      />}
      {tab==="Deliveries"&&<DeliveriesScreen customers={filteredCustomers} records={dayRecords} recordFor={recordFor}
        products={data.products} onPresent={togglePresent} onAbsent={toggleAbsent} onPacket={changePacket} search={search} setSearch={setSearch} total={deliveredCount} />}
      {tab==="Bills"&&<BillsScreen month={selectedMonth} monthLabel={titleMonth} setMonth={setSelectedMonth}
        monthTotal={monthTotal} monthLitres={monthLitres} monthDays={monthDays} customers={activeCustomers}
        records={monthRecords} productById={productById} recordTotal={recordTotal}/>}
      {tab==="Customers"&&<CustomersScreen customers={filteredCustomers} search={search} setSearch={setSearch}
        onAdd={startAddCustomer} onEdit={startEditCustomer}/>}
      {tab==="Admin"&&<AdminScreen products={data.products} customerCount={activeCustomers.length}
        onAddProduct={()=>setProductModal(true)} onImport={importSamples} onImportActual={importActualCustomers} onSignOut={()=>auth&&signOut(auth)} firebaseMode={firebaseConfigured} busy={busy} commission={commission} setCommission={setCommission}/>}
    </ScrollView>
    <BottomNav active={tab} onChange={t=>{setTab(t);setSearch("");}}/>
    <CustomerEditor visible={customerModal} editing={editing} name={name} setName={setName} phone={phone} setPhone={setPhone}
      address={address} setAddress={setAddress} onClose={()=>setCustomerModal(false)} onSave={saveCustomer}/>
    <ProductEditor visible={productModal} brand={brand} setBrand={setBrand} type={type} setType={setType}
      size={size} setSize={setSize} price={price} setPrice={setPrice} onClose={()=>setProductModal(false)} onSave={saveProduct}/>
  </SafeAreaView>;
}

function Header(){return <View style={styles.header}><View style={styles.scooter}><Text style={{fontSize:43}}>🛵</Text><Text style={{fontSize:12,position:"absolute",bottom:0,right:0}}>🥛</Text></View><View><Text style={styles.headerTitle}>Doodh Delight</Text><Text style={styles.headerSub}>Daily Milk Delivery</Text></View></View>;}
function DatePanel({date,onPrev,onNext,onToday}:{date:string;onPrev:()=>void;onNext:()=>void;onToday:()=>void}){
 return <View style={styles.datePanel}><Text style={styles.dateCaption}>Select date</Text><View style={styles.dateRow}><TouchableOpacity style={styles.dateBox} onPress={onPrev}><Text style={styles.dateText}>‹</Text><Text style={styles.dateText}>{date}</Text><Text style={styles.dateText}>›</Text></TouchableOpacity><TouchableOpacity style={styles.todayButton} onPress={onToday}><Text style={styles.todayText}>Today</Text></TouchableOpacity></View></View>;
}
function HomeScreen(p:any){
 const groups=[...new Set(p.products.map((x:Product)=>x.brand))];
 const brandColors:Record<string,string>={Heritage:"#EAF8E6",Vijaya:"#FFF9D5",Amul:"#FFF1F1",Jersey:"#FDEFF2","Dairy Products":"#EAF3FF"};
 const brandEmoji:Record<string,string>={Heritage:"🥛",Vijaya:"🐄",Amul:"🥛",Jersey:"🐮","Dairy Products":"🥣"};
 return <View>
  <Text style={styles.greeting}>Good morning 👋</Text><Text style={styles.subtitle}>Your milk delivery overview</Text>
  <Section title="Milk by Brand" subtitle="Today's total milk quantity"/>
  <View style={styles.brandGrid}>{groups.map((brand:string)=>{
    const products=p.products.filter((x:Product)=>x.brand===brand);
    const litres=p.records.reduce((sum: number,r:RecordDay)=>sum+r.lines.reduce((a:number,l:Line)=>a+((p.productById(l.productId)?.brand===brand?(p.productById(l.productId)?.sizeMl??0)*l.packets/1000:0)),0),0);
    return <View key={brand} style={styles.brandCard}><View style={[styles.brandArt,{backgroundColor:brandColors[brand]??"#F4F5F7"}]}><Text style={{fontSize:48}}>{brandEmoji[brand]??"🥛"}</Text><Text style={styles.brandArtName}>{brand}</Text></View><View style={styles.brandInfo}><Text style={styles.brandName}>{brand}</Text><Text style={styles.muted}>Milk quantity today</Text><Text style={[styles.litreValue,{color:brand==="Vijaya"?"#C99A00":GREEN}]}>{litres.toFixed(2)} L</Text></View></View>;
  })}</View>
  <Section title="Payments" />
  <View style={styles.paymentCard}><Text style={styles.paymentLabel}>Monthly bills · {p.selectedMonth}</Text><Text style={styles.paymentAmount}>{money(p.monthTotal)}</Text><View style={styles.paymentStats}><View style={{flex:1}}><Text style={styles.paymentLabel}>Delivered today</Text><Text style={[styles.statNumber,{color:GREEN}]}>{p.delivered}</Text></View><View style={styles.verticalLine}/><View style={{flex:1,paddingLeft:18}}><Text style={styles.paymentLabel}>Not marked</Text><Text style={[styles.statNumber,{color:ORANGE_DARK}]}>{p.notMarked}</Text></View></View></View>
  <Section title="Quick Glance"/>
  <View style={styles.quickGrid}><Metric label="Total Customers" value={String(p.customers)} color="#D35461" hint="Active customers"/><Metric label="Milk Delivered" value={`${p.dayLitres.toFixed(2)} L`} color={GREEN} hint="Today's quantity"/></View>
  <TouchableOpacity style={styles.actionCard} onPress={()=>p.onGo("Deliveries")}><Text style={styles.actionIcon}>✓</Text><View style={{flex:1}}><Text style={styles.actionTitle}>{p.notMarked} deliveries not marked</Text><Text style={styles.actionSub}>{p.delivered} delivered · {p.absent} absent today</Text></View><Text style={styles.chevron}>›</Text></TouchableOpacity>
  <TouchableOpacity style={styles.actionCard} onPress={()=>p.onGo("Bills")}><Text style={[styles.actionIcon,{backgroundColor:"#E9F3FF"}]}>▤</Text><View style={{flex:1}}><Text style={styles.actionTitle}>Daily report</Text><Text style={styles.actionSub}>View quantities and billing</Text></View><Text style={styles.chevron}>›</Text></TouchableOpacity>
 </View>;
}
function DeliveriesScreen(p:any){
 return <View><Text style={styles.pageTitle}>Deliveries</Text><Text style={styles.subtitle}>Mark attendance and enter milk packets</Text>
 <View style={styles.deliverySummary}><Text style={styles.summaryStrong}>{p.total} delivered</Text><Text style={styles.muted}> · {p.customers.length-p.total} not marked</Text></View>
 <Search value={p.search} onChange={p.setSearch} placeholder="Search customer / location..."/>
 {p.customers.map((c:Customer)=>{
  const r=p.recordFor(c.id);
  return <View style={styles.customerCard} key={c.id}><View style={styles.customerHeader}><View style={styles.avatar}><Text style={styles.avatarText}>{c.name.slice(0,1).toUpperCase()}</Text></View><View style={{flex:1}}><Text style={styles.customerName}>{c.name}</Text><Text style={styles.muted}>{c.address}</Text></View><TouchableOpacity onPress={()=>p.onPresent(c)} style={[styles.pill,r.present?styles.pillGreen:styles.pillGrey]}><Text style={r.present?styles.pillTextGreen:styles.pillTextGrey}>{r.present?"Present":"Mark present"}</Text></TouchableOpacity></View>
  <View style={styles.attendanceActions}><TouchableOpacity onPress={()=>p.onAbsent(c)}><Text style={styles.absentAction}>{r.absent?"✓ Absent":"Mark absent"}</Text></TouchableOpacity><Text style={styles.deliveryTotal}>{money(r.lines.reduce((s: number,l:Line)=>s+l.packets*l.unitPrice,0))}</Text></View>
  {r.present&&<View style={styles.packetArea}>{p.products.filter((x:Product)=>x.active).map((prod:Product)=>{const line=r.lines.find((x:Line)=>x.productId===prod.id);return <View style={styles.packetRow} key={prod.id}><View style={{flex:1}}><Text style={styles.productTitle}>{prod.brand} · {prod.type}</Text><Text style={styles.muted}>{prod.sizeMl} ml · {money(c.prices?.[prod.id]??prod.price)}</Text></View><TouchableOpacity style={styles.counter} onPress={()=>p.onPacket(c,prod,-1)}><Text style={styles.counterText}>−</Text></TouchableOpacity><Text style={styles.count}>{line?.packets??0}</Text><TouchableOpacity style={styles.counterPlus} onPress={()=>p.onPacket(c,prod,1)}><Text style={styles.counterPlusText}>+</Text></TouchableOpacity></View>})}</View>}
  </View>;
 })}
 </View>;
}
function BillsScreen(p:any){
 const [calc,setCalc]=useState(false);
 const customerTotals=p.customers.map((c:Customer)=>({customer:c,total:p.records.filter((r:RecordDay)=>r.customerId===c.id).reduce((s:number,r:RecordDay)=>s+p.recordTotal(r),0),litres:p.records.filter((r:RecordDay)=>r.customerId===c.id).reduce((s:number,r:RecordDay)=>s+r.lines.reduce((a:number,l:Line)=>a+(p.productById(l.productId)?.sizeMl??0)*l.packets/1000,0),0)})).filter((x:any)=>x.total>0);
 return <View><Text style={styles.pageTitle}>Bills</Text><Text style={styles.subtitle}>Monthly customer billing</Text>
 <View style={styles.billIntro}><Text style={styles.blueEyebrow}>MONTHLY SUMMARY</Text><Text style={styles.billIntroTitle}>Customer milk bills</Text><Text style={styles.muted}>Choose a month to calculate every customer's bill.</Text>
 <View style={styles.monthSelect}><TextInput value={p.month} onChangeText={p.setMonth} placeholder="YYYY-MM" style={styles.monthInput}/><Primary label="Calculate bills" onPress={()=>setCalc(true)}/></View>
 <View style={styles.billMetrics}><SmallMetric label="ALL CUSTOMER BILLS" value={money(p.monthTotal)} color={GREEN}/><SmallMetric label="TOTAL MILK" value={`${p.monthLitres.toFixed(2)} L`} color={BLUE}/><SmallMetric label="MILK-TAKEN DAYS" value={String(p.monthDays)} color="#8246B7"/></View>
 <View style={styles.breakdownHeader}><View><Text style={styles.sectionHeading}>Customer breakdown</Text><Text style={styles.muted}>{customerTotals.length} customers · {p.monthLabel}</Text></View><Text style={styles.allPill}>ALL</Text></View>
 {customerTotals.length===0?<Text style={styles.emptyText}>No deliveries recorded for this month yet. Add milk packets in Deliveries.</Text>:customerTotals.map((x:any,i:number)=><View style={styles.billCustomer} key={x.customer.id}><View style={styles.rank}><Text style={styles.rankText}>{String(i+1).padStart(2,"0")}</Text></View><View style={{flex:1}}><Text style={styles.customerName}>{x.customer.name}</Text><Text style={styles.muted}>{x.customer.address} · {x.litres.toFixed(2)} L</Text></View><Text style={styles.billValue}>{money(x.total)}</Text></View>)}
 </View></View>;
}
function CustomersScreen(p:any){
 return <View><View style={styles.pageTitleRow}><View><Text style={styles.pageTitle}>Customers</Text><Text style={styles.subtitle}>{p.customers.length} active customer/location profiles</Text></View><TouchableOpacity style={styles.addButton} onPress={p.onAdd}><Text style={styles.addButtonText}>＋ Add</Text></TouchableOpacity></View>
 <Search value={p.search} onChange={p.setSearch} placeholder="Search customer / location..."/>
 {p.customers.map((c:Customer)=><View style={styles.customerListCard} key={c.id}>
  <View style={styles.avatar}><Text style={styles.avatarText}>{c.name.slice(0,1).toUpperCase()}</Text></View>
  <View style={{flex:1}}>
   <Text style={styles.customerName}>{c.name}</Text>
   <Text style={styles.muted}>{(c.milkItems?.length??Object.keys(c.prices??{}).length)||0} milk assignments · {(c.dailyTotalLitres??0).toFixed(2)} L/day</Text>
   {(c.milkItems??[]).map((item:any,i:number)=><Text key={`${c.id}-milk-${i}`} style={styles.productTitle}>
    {item.brandType} · {item.dailyLitres} L/day · {item.priceUnit==="perPacket"?`${money(item.pricePerPacket??0)} / ${item.packetSizeMl??200} ml packet`:`${money(item.pricePerLitre??0)} / L`}
   </Text>)}
  </View>
  <TouchableOpacity style={styles.editButton} onPress={()=>p.onEdit(c)}><Text style={styles.editText}>Edit</Text></TouchableOpacity>
 </View>)}
 </View>;
}
function AdminScreen(p:any){
 const [open,setOpen]=useState("Add Customer");
 const sections=[["Add Customer","＋"],["Existing Customers","👥"],["Milk Prices","₹"],["Commission","%"],["Firebase Database","☁"]];
 return <View><Text style={styles.blueEyebrow}>PERSONALISE YOUR APP</Text><Text style={styles.pageTitle}>More & Settings</Text><Text style={styles.subtitle}>Manage milk pricing, commission and secure cloud sync.</Text>
 <View style={styles.firebaseCard}><View style={[styles.dot,{backgroundColor:p.firebaseMode?GREEN:ORANGE}]}/><View style={{flex:1}}><Text style={styles.customerName}>{p.firebaseMode?"Firebase configured":"Demo mode active"}</Text><Text style={styles.muted}>{p.firebaseMode?"Cloud Firestore connected after admin sign-in.":"Configure Firebase to sync data to the cloud."}</Text></View>{p.firebaseMode&&<Text style={styles.connected}>LIVE</Text>}</View>
 {sections.map(([title,icon])=><View key={title} style={styles.adminSection}><TouchableOpacity style={styles.adminSectionHead} onPress={()=>setOpen(open===title?"":title)}><View style={styles.adminIcon}><Text style={styles.adminIconText}>{icon}</Text></View><Text style={styles.adminSectionTitle}>{title}</Text><Text style={styles.adminChevron}>{open===title?"⌃":"⌄"}</Text></TouchableOpacity>
 {open===title&&<View style={styles.adminBody}>
  {title==="Add Customer"&&<Text style={styles.muted}>Use the Customers tab and tap + Add to create a customer profile.</Text>}
  {title==="Existing Customers"&&<Text style={styles.muted}>{p.customerCount} customer profiles are available. Open Customers to search or edit a profile.</Text>}
  {title==="Milk Prices"&&<><Text style={styles.muted}>Milk brands, sizes and rates from your customer list.</Text>{p.products.map((x:Product)=><View style={styles.priceRow} key={x.id}><Text style={styles.productTitle}>{x.brand} · {x.type} ({x.sizeMl} ml)</Text><Text style={styles.billValue}>{money(x.price)}</Text></View>)}<Primary label="＋ Add milk type / price" onPress={p.onAddProduct}/></>}
  {title==="Commission"&&<><Text style={styles.muted}>Commission rate is a prototype setting. Your actual commission rule can be added later.</Text><Text style={styles.priceRow}>Current commission: {p.commission}%</Text></>}
  {title==="Firebase Database"&&<><Text style={styles.muted}>Save your uploaded customer list, assigned milk types, daily quantities and prices into Cloud Firestore.</Text><Primary label={p.busy?"Importing…":"Add my customer list (100 rows)"} onPress={p.onImportActual} disabled={p.busy}/><Text style={[styles.muted,{marginTop:12}]}>All 100 original milk assignment rows are retained. Repeated milk types are not merged.</Text></>}
 </View>}
 </View>)}
 {p.firebaseMode&&<TouchableOpacity style={styles.signOut} onPress={p.onSignOut}><Text style={styles.editText}>Sign out admin</Text></TouchableOpacity>}
 </View>;
}
function BottomNav({active,onChange}:{active:Tab;onChange:(t:Tab)=>void}){
 const items:[Tab,string,string][]=[["Home","⌂","Home"],["Deliveries","🛵","Deliveries"],["Bills","▤","Bills"],["Customers","👥","Customers"],["Admin","⚙","Admin"]];
 return <View style={styles.bottomNav}>{items.map(([tab,icon,label])=><TouchableOpacity key={tab} style={styles.navItem} onPress={()=>onChange(tab)}><Text style={[styles.navIcon,active===tab&&styles.navActive]}>{icon}</Text><Text style={[styles.navLabel,active===tab&&styles.navActive]}>{label}</Text></TouchableOpacity>)}</View>;
}
function Section({title,subtitle}:{title:string;subtitle?:string}){return <View style={styles.sectionBlock}><Text style={styles.sectionHeading}>{title}</Text>{!!subtitle&&<Text style={styles.sectionSub}>{subtitle}</Text>}</View>;}
function Metric({label,value,color,hint}:{label:string;value:string;color:string;hint:string}){return <View style={styles.metricCard}><Text style={styles.metricLabel}>{label}</Text><Text style={[styles.metricValue,{color}]}>{value}</Text><Text style={styles.metricHint}>{hint}</Text></View>;}
function SmallMetric({label,value,color}:{label:string;value:string;color:string}){return <View style={styles.smallMetric}><Text style={styles.smallMetricLabel}>{label}</Text><Text style={[styles.smallMetricValue,{color}]}>{value}</Text></View>;}
function Search({value,onChange,placeholder}:{value:string;onChange:(s:string)=>void;placeholder:string}){return <TextInput value={value} onChangeText={onChange} placeholder={placeholder} placeholderTextColor="#9AA2AD" style={styles.search}/>;}
function Field({label,value,onChange,placeholder,keyboard}:{label:string;value:string;onChange:(s:string)=>void;placeholder:string;keyboard?:any}){return <View style={{marginBottom:12}}><Text style={styles.fieldLabel}>{label}</Text><TextInput value={value} onChangeText={onChange} placeholder={placeholder} keyboardType={keyboard??"default"} style={styles.input}/></View>;}
function Primary({label,onPress,disabled}:{label:string;onPress:()=>void;disabled?:boolean}){return <TouchableOpacity disabled={disabled} onPress={onPress} style={[styles.primary,disabled&&{opacity:.6}]}><Text style={styles.primaryText}>{label}</Text></TouchableOpacity>;}
function CustomerEditor(p:any){return <Modal visible={p.visible} transparent animationType="slide" onRequestClose={p.onClose}><KeyboardAvoidingView behavior={Platform.OS==="ios"?"padding":undefined} style={styles.modalShade}><View style={styles.modalCard}><Text style={styles.modalTitle}>{p.editing?"Edit customer":"Add customer"}</Text><Field label="Customer name" value={p.name} onChange={p.setName} placeholder="Enter customer name"/><Field label="Phone number" value={p.phone} onChange={p.setPhone} placeholder="Enter phone number" keyboard="phone-pad"/><Field label="Address / delivery location" value={p.address} onChange={p.setAddress} placeholder="Enter address"/><Primary label="Save customer" onPress={p.onSave}/><TouchableOpacity onPress={p.onClose} style={styles.cancel}><Text style={styles.muted}>Cancel</Text></TouchableOpacity></View></KeyboardAvoidingView></Modal>;}
function ProductEditor(p:any){return <Modal visible={p.visible} transparent animationType="slide" onRequestClose={p.onClose}><KeyboardAvoidingView behavior={Platform.OS==="ios"?"padding":undefined} style={styles.modalShade}><View style={styles.modalCard}><Text style={styles.modalTitle}>Add milk type & price</Text><Field label="Brand" value={p.brand} onChange={p.setBrand} placeholder="e.g. Heritage"/><Field label="Milk type" value={p.type} onChange={p.setType} placeholder="e.g. TM / Toned Milk"/><Field label="Packet size (ml)" value={p.size} onChange={p.setSize} placeholder="500" keyboard="numeric"/><Field label="Price per packet (₹)" value={p.price} onChange={p.setPrice} placeholder="28" keyboard="decimal-pad"/><Primary label="Save milk product" onPress={p.onSave}/><TouchableOpacity onPress={p.onClose} style={styles.cancel}><Text style={styles.muted}>Cancel</Text></TouchableOpacity></View></KeyboardAvoidingView></Modal>;}

const styles=StyleSheet.create({
 safe:{flex:1,backgroundColor:BG},center:{flex:1,alignItems:"center",justifyContent:"center",backgroundColor:BG},loginBox:{flex:1,justifyContent:"center",padding:24},brand:{fontSize:30,fontWeight:"900",color:ORANGE_DARK},header:{height:120,backgroundColor:ORANGE,flexDirection:"row",alignItems:"center",paddingHorizontal:28,borderBottomLeftRadius:48,borderBottomRightRadius:48,elevation:5},scooter:{width:90,height:80,alignItems:"center",justifyContent:"center",marginRight:18},headerTitle:{fontSize:29,fontWeight:"900",color:"#FFF",letterSpacing:-.5},headerSub:{fontSize:15,fontWeight:"800",color:"#FFF",marginTop:3,letterSpacing:.3},scroll:{paddingBottom:28},datePanel:{backgroundColor:"#FFF",marginTop:16,marginHorizontal:0,padding:18,borderRadius:22,borderWidth:1,borderColor:"#E0E4EA",elevation:2},dateCaption:{color:"#687687",fontWeight:"800",fontSize:14,marginBottom:12},dateRow:{flexDirection:"row",gap:12},dateBox:{flex:1,borderWidth:1.5,borderColor:"#E2E5E9",borderRadius:16,paddingHorizontal:16,paddingVertical:15,flexDirection:"row",justifyContent:"space-between",alignItems:"center"},dateText:{fontSize:17,fontWeight:"800",color:NAVY},todayButton:{backgroundColor:BLUE,paddingHorizontal:20,justifyContent:"center",borderRadius:16},todayText:{fontSize:16,fontWeight:"900",color:"#FFF"},greeting:{fontSize:30,fontWeight:"900",color:"#151B28",marginHorizontal:26,marginTop:35},subtitle:{fontSize:16,color:"#858C96",marginHorizontal:28,marginTop:4,marginBottom:20},sectionBlock:{marginHorizontal:28,marginTop:18,marginBottom:12},sectionHeading:{fontSize:22,fontWeight:"900",color:"#151B28"},sectionSub:{fontSize:14,color:"#7E8792",marginTop:7},brandGrid:{flexDirection:"row",flexWrap:"wrap",gap:12,marginHorizontal:28},brandCard:{width:"48%",flexGrow:1,backgroundColor:"#FFF",borderRadius:25,overflow:"hidden",elevation:2,marginBottom:2},brandArt:{height:132,alignItems:"center",justifyContent:"center"},brandArtName:{fontSize:15,fontWeight:"900",color:NAVY,marginTop:2},brandInfo:{padding:14},brandName:{fontSize:19,fontWeight:"900",color:"#1D2737"},muted:{fontSize:13,color:"#89919B",marginTop:4},litreValue:{fontSize:25,fontWeight:"900",marginTop:10},paymentCard:{backgroundColor:"#FFF",borderRadius:26,marginHorizontal:28,padding:20,borderWidth:1,borderColor:"#E1E5EA",elevation:2},paymentLabel:{fontSize:15,fontWeight:"700",color:"#7E8792"},paymentAmount:{fontSize:31,fontWeight:"900",color:NAVY,marginTop:12},paymentStats:{flexDirection:"row",borderTopWidth:1,borderColor:"#E7E9ED",marginTop:18,paddingTop:17},verticalLine:{width:1,backgroundColor:"#E5E8ED"},statNumber:{fontSize:26,fontWeight:"900",marginTop:4},quickGrid:{flexDirection:"row",gap:12,marginHorizontal:28},metricCard:{flex:1,backgroundColor:"#FFF",borderRadius:22,padding:15,borderWidth:2,borderColor:"#E6D5D8"},metricLabel:{fontSize:14,color:"#7B828C"},metricValue:{fontSize:28,fontWeight:"900",marginTop:6},metricHint:{fontSize:13,color:"#9AA0A8",marginTop:6},actionCard:{backgroundColor:"#FFF",borderRadius:22,marginHorizontal:28,marginTop:14,padding:16,flexDirection:"row",alignItems:"center",borderWidth:1.5,borderColor:"#D9E0EB"},actionIcon:{width:54,height:54,borderRadius:28,backgroundColor:"#FFF0F0",color:"#D45162",textAlign:"center",textAlignVertical:"center",fontSize:29,overflow:"hidden",marginRight:14},actionTitle:{fontSize:16,fontWeight:"900",color:"#204A70"},actionSub:{fontSize:13,fontWeight:"700",color:"#939AA3",marginTop:3},chevron:{fontSize:30,color:"#204A70",fontWeight:"900",marginLeft:8},bottomNav:{height:82,backgroundColor:"#FFF",borderTopWidth:1,borderColor:"#E7E9ED",flexDirection:"row",alignItems:"center",justifyContent:"space-around",elevation:12},navItem:{flex:1,alignItems:"center",justifyContent:"center",gap:2},navIcon:{fontSize:25,color:"#91A1B0",fontWeight:"900"},navLabel:{fontSize:11,color:"#939AA3",fontWeight:"800"},navActive:{color:"#28618E"},pageTitle:{fontSize:30,fontWeight:"900",color:"#151B28",marginHorizontal:28,marginTop:25},pageTitleRow:{flexDirection:"row",justifyContent:"space-between",alignItems:"center",marginRight:28},addButton:{backgroundColor:ORANGE,paddingHorizontal:18,paddingVertical:13,borderRadius:15,marginTop:22},addButtonText:{color:"#FFF",fontSize:15,fontWeight:"900"},search:{backgroundColor:"#FFF",borderWidth:1.5,borderColor:"#E9E0D5",borderRadius:17,paddingHorizontal:17,paddingVertical:16,fontSize:15,color:NAVY,marginHorizontal:28,marginBottom:12},deliverySummary:{marginHorizontal:28,backgroundColor:"#E8F6EF",padding:12,borderRadius:13,flexDirection:"row",marginBottom:12},summaryStrong:{color:GREEN,fontWeight:"900"},customerCard:{backgroundColor:"#FFF",marginHorizontal:28,marginBottom:12,padding:15,borderRadius:20,borderWidth:1,borderColor:"#E5E8EC",elevation:1},customerHeader:{flexDirection:"row",alignItems:"center",gap:11},avatar:{width:52,height:52,borderRadius:28,backgroundColor:"#EAF3FC",alignItems:"center",justifyContent:"center"},avatarText:{fontSize:22,fontWeight:"900",color:"#28618E"},customerName:{fontSize:16,fontWeight:"900",color:NAVY},pill:{paddingHorizontal:12,paddingVertical:9,borderRadius:20},pillGreen:{backgroundColor:"#E6F7EC"},pillGrey:{backgroundColor:"#EEF0F3"},pillTextGreen:{color:GREEN,fontWeight:"900",fontSize:11},pillTextGrey:{color:"#75808C",fontWeight:"900",fontSize:11},attendanceActions:{flexDirection:"row",justifyContent:"space-between",marginTop:12,borderTopWidth:1,borderColor:"#EEF0F2",paddingTop:10},absentAction:{color:"#C26E42",fontWeight:"800",fontSize:12},deliveryTotal:{color:GREEN,fontWeight:"900"},packetArea:{marginTop:10},packetRow:{flexDirection:"row",alignItems:"center",paddingVertical:9,borderTopWidth:1,borderColor:"#F0F2F4"},productTitle:{fontSize:13,fontWeight:"800",color:NAVY},counter:{width:30,height:30,borderRadius:9,backgroundColor:"#EEF1F4",alignItems:"center",justifyContent:"center"},counterPlus:{width:30,height:30,borderRadius:9,backgroundColor:ORANGE,alignItems:"center",justifyContent:"center"},counterText:{fontSize:20,fontWeight:"900",color:NAVY},counterPlusText:{fontSize:20,fontWeight:"900",color:"#FFF"},count:{width:28,textAlign:"center",fontWeight:"900",color:NAVY},billIntro:{marginHorizontal:28,backgroundColor:"#FFF",borderRadius:24,padding:20,borderWidth:1,borderColor:"#E3E7EC"},blueEyebrow:{fontSize:12,fontWeight:"900",letterSpacing:1.2,color:BLUE,marginHorizontal:28,marginTop:24},billIntroTitle:{fontSize:20,fontWeight:"900",color:NAVY,marginTop:8},monthSelect:{backgroundColor:"#F7F9FB",borderWidth:1,borderColor:"#E4E8EE",borderRadius:18,padding:14,marginTop:22},monthInput:{backgroundColor:"#FFF",borderWidth:1,borderColor:"#E0E5EB",borderRadius:12,padding:13,fontSize:16,color:NAVY,marginBottom:12},primary:{backgroundColor:BLUE,paddingVertical:15,borderRadius:13,alignItems:"center",marginTop:5},primaryText:{color:"#FFF",fontSize:15,fontWeight:"900"},billMetrics:{flexDirection:"row",gap:8,marginTop:22},smallMetric:{flex:1,minWidth:0,borderWidth:1.5,borderColor:"#E4E8ED",borderRadius:16,padding:11},smallMetricLabel:{fontSize:9,fontWeight:"900",color:"#77818D"},smallMetricValue:{fontSize:15,fontWeight:"900",marginTop:9},breakdownHeader:{flexDirection:"row",justifyContent:"space-between",alignItems:"center",marginTop:30,marginBottom:12},allPill:{backgroundColor:"#EEF4FF",color:BLUE,fontWeight:"900",paddingHorizontal:15,paddingVertical:8,borderRadius:20,overflow:"hidden"},billCustomer:{flexDirection:"row",alignItems:"center",gap:10,padding:13,borderWidth:1,borderColor:"#E6E9ED",borderRadius:17,marginBottom:9},rank:{width:42,height:42,borderRadius:13,backgroundColor:"#EEF5FF",alignItems:"center",justifyContent:"center"},rankText:{color:BLUE,fontWeight:"900"},billValue:{fontSize:15,color:BLUE,fontWeight:"900"},emptyText:{color:MUTED,fontSize:13,paddingVertical:18},customerListCard:{backgroundColor:"#FFF",marginHorizontal:28,marginBottom:10,padding:15,borderRadius:22,borderWidth:1,borderColor:"#E4E8EC",flexDirection:"row",alignItems:"center",gap:12},editButton:{backgroundColor:"#EEF5FF",paddingHorizontal:15,paddingVertical:10,borderRadius:13},editText:{color:"#28618E",fontWeight:"900"},firebaseCard:{marginHorizontal:28,marginTop:18,backgroundColor:"#FFF",padding:14,borderRadius:17,flexDirection:"row",alignItems:"center",gap:10,borderWidth:1,borderColor:"#E4E8EC"},dot:{width:10,height:10,borderRadius:5},connected:{color:GREEN,fontWeight:"900",fontSize:10},adminSection:{marginHorizontal:28,marginTop:12,backgroundColor:"#FFF",borderRadius:20,borderWidth:1,borderColor:"#E2E6EB",overflow:"hidden"},adminSectionHead:{padding:15,flexDirection:"row",alignItems:"center",gap:12},adminIcon:{width:48,height:48,borderRadius:15,backgroundColor:"#EEF5FF",alignItems:"center",justifyContent:"center"},adminIconText:{fontSize:23,color:BLUE,fontWeight:"900"},adminSectionTitle:{flex:1,fontSize:15,fontWeight:"900",color:NAVY},adminChevron:{fontSize:25,color:"#47866C",fontWeight:"900"},adminBody:{padding:15,borderTopWidth:1,borderColor:"#EEF0F2"},priceRow:{paddingVertical:11,borderBottomWidth:1,borderColor:"#EEF0F2",flexDirection:"row",justifyContent:"space-between",alignItems:"center"},signOut:{alignSelf:"flex-start",margin:28,padding:12,backgroundColor:"#EEF5FF",borderRadius:12},fieldLabel:{fontSize:11,fontWeight:"900",color:"#77818D",marginBottom:6},input:{backgroundColor:"#FBFCFD",borderWidth:1,borderColor:"#E0E5EA",borderRadius:12,paddingHorizontal:13,paddingVertical:12,fontSize:14,color:NAVY},modalShade:{flex:1,backgroundColor:"rgba(10,20,30,.45)",justifyContent:"center",padding:20},modalCard:{backgroundColor:"#FFF",padding:20,borderRadius:23},modalTitle:{fontSize:22,fontWeight:"900",color:NAVY,marginBottom:18},cancel:{alignItems:"center",padding:13},error:{color:"#C0392B",marginBottom:10}
});
