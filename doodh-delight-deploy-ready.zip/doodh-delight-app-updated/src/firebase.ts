import { getApp, getApps, initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

// Shared Firebase project configuration for Android and web.
// Firebase web apiKey is an identifier, not an admin credential.
// Protect data with Authentication and Firestore Security Rules.
const firebaseConfig = {
  apiKey: "AIzaSyA39Avb8rwC0OpbnS0rvEOy8bUJobZkpE0",
  authDomain: "doodhdelight.firebaseapp.com",
  projectId: "doodhdelight",
  storageBucket: "doodhdelight.firebasestorage.app",
  messagingSenderId: "553609350331",
  appId: "1:553609350331:web:725e683755afa3a4fd6d9e",
  measurementId: "G-40X0QDXKZJ"
};

const app = getApps().length ? getApp() : initializeApp(firebaseConfig);

export const firebaseConfigured = true;
export const auth = getAuth(app);
export const db = getFirestore(app);
export { app };
